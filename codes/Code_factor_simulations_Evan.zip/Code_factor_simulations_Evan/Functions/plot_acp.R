#histogram of acceptance rate with respect to different eta_i
# i = 1,2, .... , n

plot_acp = function(nrun,burn,gibbs){
   acp = gibbs$acp
   hist(acp/(nrun-burn),freq = F)
   lines(density(acp/(nrun-burn)),col="red")
}
