####### CLEAN CODE for simulations ######
library(mvtnorm)
library(MASS)
library(beepr)
library(psych)
library(bayesSurv)
library('PIE')
library('glmnet')
library(RAMP)
library(hierNet)
library(FAMILY)
library(RCurl)
library(R.utils)
sourceDirectory("/Functions")

# generate the data
data = generate_factor_model(p = 10,n = 100,k_true = 4)
#data = generate_indep_model(p = 10,n = 100)
y = data$y; X = data$X; beta_true = data$beta_true; 
Omega_true = data$Omega_true;
y_test = data$y_test; X_test = data$X_test
p = ncol(X);

#run Factor model
nrun = 1500; burn = 1000;
gibbs_DL = gibbs_factor_dirichlet_laplace(y, X ,nrun = nrun, burn = burn, thin = 1, 
                                          delta_rw = 0.008, epsilon_rw = 0.5,
                                          a = p, k = floor(log(ncol(X))*3))

#acp: best when the mean is < .25 and the max is not greater than .4
plot_acp(nrun,burn,gibbs_DL)

#Competitors
hiernet = Hiernet_fct(y, X, X_test, y_test)
Family = FAMILY_fct(y, X, X_test, y_test)
PIE = PIE_fct(y, X, X_test, y_test)
RAMP = RAMP_fct(y, X, X_test, y_test)

#Compare errors 
compute_errors(hiernet,Family,PIE,RAMP,
               y,y_test,Omega_true,beta_true,
               gibbs_DL)

#estimates
alpha_bayes_hat = mean(gibbs_DL$alpha_bayes)
betabayes_hat = apply(gibbs_DL$beta_bayes,2,mean)
Omegabayes_hat = apply(gibbs_DL$Omega_bayes,c(2,3),mean)

# Coverage
coverage = coverage_int(gibbs_DL$beta_bayes,gibbs_DL$Omega_bayes)

#Rate recovery and Coverage
alpha = 0.05
rate_recovery_maineff(gibbs_DL,alpha = alpha,beta_true = beta_true,
                      hiernet$beta,Family$beta,PIE$beta,RAMP$beta)
rate_recovery_interactions(gibbs_DL,alpha = alpha,Omega_true=Omega_true,
                           hiernet$Omega,Family$Omega,PIE$Omega,RAMP$Omega)

alpha = seq(0.01,0.14,by = 0.01)
cov_f = cov_f2 = numeric(length(alpha))
for(i in 1:length(alpha)){
   rate = rate_recovery_interactions(gibbs_DL,alpha = alpha[i],Omega_true=Omega_true,
                              hiernet$Omega,Family$Omega,PIE$Omega,RAMP$Omega)
   cov_f[i] = rate$TN[1]
   cov_f2[i] = rate$TN[2]
}

plot(1-alpha,cov_f, ylim = c(min(cov_f),1),pch=16)
lines(1-alpha,cov_f2,col="red",ty="p",pch=16)
abline(a = 0, b = 1)

plot(1-alpha,cov_f2,col="red",ty="p",pch=16)
abline(a = 0, b = 1)
